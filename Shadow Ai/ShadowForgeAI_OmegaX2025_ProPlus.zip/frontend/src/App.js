import React, { useEffect, useState } from 'react';

function App() {
  const [status, setStatus] = useState({});

  useEffect(() => {
    fetch('/api/status')
      .then(res => res.json())
      .then(data => setStatus(data));
  }, []);

  return (
    <div className="app-container">
      <header className="header">🚀 ShadowForgeAI OmegaX2025 Pro+</header>
      <div className="status-panel">
        <p>Status: {status.status}</p>
        <p>Engine: {status.engine}</p>
        <p>Version: {status.version}</p>
        <p className="branding">Powered by Mubashar Ali (Hideable for Pro users)</p>
      </div>
    </div>
  );
}

export default App;