from flask import Flask, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

@app.route('/api/status')
def status():
    return jsonify({
        "status": "Operational",
        "engine": "EvoSim-AI OmegaX2025 Core",
        "version": "1.0.0-Pro+"
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)