from flask import jsonify, request
from .sample_manager import generate_sample, get_status

def register_routes(app):
    @app.route('/api/status', methods=['GET'])
    def status():
        return jsonify(get_status())

    @app.route('/api/generate', methods=['POST'])
    def generate():
        data = request.get_json()
        return jsonify(generate_sample(data))