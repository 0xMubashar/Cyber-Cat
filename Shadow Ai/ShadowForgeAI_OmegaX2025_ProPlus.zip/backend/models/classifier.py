class Classifier:
    def __init__(self):
        self.model = None

    def detect(self, features):
        return {"detected": False, "confidence": 0.3}