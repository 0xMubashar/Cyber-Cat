from aicore.agent.rl_agent import RLAgent
from aicore.env.simulation_env import SimulationEnv
from aicore.classifier.av_model import AVClassifier

if __name__ == "__main__":
    env = SimulationEnv()
    agent = RLAgent(env)
    av = AVClassifier()
    agent.train()
