class AVClassifier:
    def __init__(self):
        pass

    def predict(self, features):
        # Simple rule-based simulation
        if "OpenProcess" in features["apis"] or features["entropy"] > 4.0:
            return 1  # Detected
        return 0  # Not detected
