import random
from aicore.mutation.feature_mutator import mutate_features
from aicore.classifier.av_model import AVClassifier

class SimulationEnv:
    def __init__(self):
        self.classifier = AVClassifier()
        self.sample = {"entropy": 3.5, "apis": ["CreateFile", "WriteFile"]}

    def reset(self):
        self.sample = {"entropy": 3.5, "apis": ["CreateFile", "WriteFile"]}
        return self.sample

    def step(self, action):
        mutated = mutate_features(self.sample, action)
        label = self.classifier.predict(mutated)
        reward = 1.0 if label == 0 else -1.0
        done = True
        return mutated, reward, done

    def sample_action(self):
        return random.choice(["add_api", "increase_entropy", "rename_string"])
