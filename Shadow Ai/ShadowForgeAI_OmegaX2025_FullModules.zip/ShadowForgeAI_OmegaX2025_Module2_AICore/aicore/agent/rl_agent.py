class RLAgent:
    def __init__(self, env):
        self.env = env
        self.episodes = 10

    def train(self):
        for episode in range(self.episodes):
            state = self.env.reset()
            done = False
            while not done:
                action = self.env.sample_action()
                state, reward, done = self.env.step(action)
                print(f"Episode {episode}, Action: {action}, Reward: {reward}")
