def log(message):
    print("[LOG]", message)
