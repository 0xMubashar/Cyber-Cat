def mutate_features(sample, action):
    if action == "add_api":
        sample["apis"].append("OpenProcess")
    elif action == "increase_entropy":
        sample["entropy"] += 1.0
    elif action == "rename_string":
        sample["apis"] = [api.replace("File", "Document") for api in sample["apis"]]
    return sample
