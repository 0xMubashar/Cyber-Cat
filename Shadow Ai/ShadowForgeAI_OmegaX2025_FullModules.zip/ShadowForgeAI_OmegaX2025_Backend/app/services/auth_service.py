from datetime import timedelta, datetime
from jose import jwt

SECRET_KEY = "UltraSecretKey_ChangeThis"
ALGORITHM = "HS256"

fake_users_db = {
    "admin": {"username": "admin", "password": "admin123"}
}

def authenticate_user(username: str, password: str):
    user = fake_users_db.get(username)
    if user and user["password"] == password:
        return user
    return None

def create_access_token(username: str):
    expire = datetime.utcnow() + timedelta(hours=1)
    to_encode = {"sub": username, "exp": expire}
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
