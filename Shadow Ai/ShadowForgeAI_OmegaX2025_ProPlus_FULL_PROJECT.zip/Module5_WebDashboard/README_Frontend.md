
# React Frontend (To Be Connected)
This folder is a placeholder for the React dashboard interface that connects to the Flask API.
